

unsigned int IoTPwmInit(unsigned int port);

unsigned int IoTPwmDeinit(unsigned int port);//取消初始化

unsigned int IoTPwmStart(unsigned int port, unsigned short duty, unsigned int freq);


unsigned int IoTPwmStop(unsigned int port);


