char get_tem();

void message_task1();

void message_go();

void gpio_device();
